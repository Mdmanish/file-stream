from django.apps import AppConfig


class FileStreamConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'file_stream'
